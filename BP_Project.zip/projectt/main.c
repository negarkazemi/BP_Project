//file kardan moonde 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <stdbool.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#define WIDTH 430
#define HEIGHT 850


struct Student 
{
    char FirstName[20];
    char LastName[20];
    char ID[20];
    char City[20];
};


struct Node 
{
    struct Student data;
    struct Node* prev;
    struct Node* next;
};

void insert(struct Node** head, struct Student student);

void printLinkedList(struct Node* head);

void lowercase(struct Student newstude);

void addstudent(struct Node** head);

void removestudent(struct Node** head);

void search(struct Node** head);

void randomsort(struct Student Students[]);

void bubblesort(struct Student Students[], int how, int which );

void insertionsort(struct Student Students[], int how, int which );
    
void selectionsort(struct Student Students[], int how, int which );

void finalfile (struct Node** head);

void sort(struct Student Students[]);

void get_text_and_rect(SDL_Renderer *renderer , int x, int y, char *text,TTF_Font *font, SDL_Texture **texture, SDL_Rect *rect);


int main(int argc, char* argv[]) 
{
    struct Node* head = NULL;

    struct Student student[100]= {"ali", "akbari", "40223001", "tehran",
    "fatemeh", "ahmadi", "40223002", "tehran",
    "niloofar", "ahangari", "40223003", "tabriz",
    "mohadeseh", "behjat", "40223004", "shiraz",
    "behzad", "bandari", "40223005", "bandarAbbas",
    "fatemeh", "bozorgi", "40223006", "tehran",
    "arezou", "barzegar", "40223007", "isfehan",
    "kian", "taheri", "40223008", "oroumie",
    "ali", "taleghani", "40223009", "rasht",
    "lale", "jamali", "40223010", "noshahr",
    "farhad", "jafari", "40223011", "tehran",
    "farbod", "jamshidi", "40223012", "lahijan",
    "niloofar", "cheshmeh", "40223013", "karaj",
    "nazanin", "hanedi", "40223014", "shiraz",
    "nafas", "khaleghi", "40223015", "rasht",
    "amin", "khosravi", "40223016", "tehran",
    "arad", "khosravi", "40223017", "yazd",
    "kian", "dori", "40223018", "mashhad",
    "ali", "dashti", "40223019", "boushehr",
    "fereshteh", "rezvani", "40223020", "ilam",
    "ahmad", "radesh", "40223021", "ghom",
    "mohammad", "rahmati", "40223022", "lahijan",
    "nila", "rashti", "40223023", "rasht",
    "mohana", "soleimani", "40223024", "sari",
    "mahdi", "sorouri", "40223025", "kermanshah",
    "reza", "salehi", "40223026", "shiraz",
    "kiana", "sohrevadi", "40223027", "yazd",
    "maryam", "sheikhi", "40223028", "tabriz",
    "roz", "sharghi", "40223029", "tehran",
    "zahra", "shahi", "40223030", "ghom",
    "diana", "shadravan", "40223031", "ahvaz",
    "mohammad", "shafiee", "40223032", "tehran",
    "radin", "shafizadeh", "40223033", "hamedan",
    "nika", "sedaghat", "40223034", "taleghan",
    "maral", "solati", "40223035", "kermanshah",
    "zhaleh", "sameti", "40223036", "sarein",
    "mobina", "zabeti", "40223037", "abadan",
    "mona", "abedi", "40223038", "tabriz",
    "mani", "alavi", "40223039", "birjand",
    "neda", "asgari", "40223040", "arak",
    "roya", "abdollahi", "40223041", "karaj",
    "sahar", "oghbai", "40223042", "tehran",
    "arash", "taheri", "40223043", "qazvin",
    "noura", "toosi", "40223044", "khorramabad",
    "yeganeh", "solati", "40223045", "kermanshah",
    "zhaleh", "sadeghi", "40223046", "zanjan",
    "farshad", "gholipour", "40223047", "rasht",
    "artin", "gholizadeh", "40223048", "neyshabur",
    "nima", "gholami", "40223049", "khansar",
    "neda", "fatehi", "40223050", "arak",
    "rozhin", "falahat", "40223051", "ramsar",
    "elena", "falahatpisheh", "40223052", "tehran",
    "arman", "fereidouni", "40223053", "qazvin",
    "saeed", "fathi", "40223054", "shahrekord",
    "hamed", "farokh", "40223055", "yasuj",
    "aynaz", "farokhi", "40223056", "poldokhtar",
    "melika", "frouhar", "40223057", "tabas",
    "nadia", "gholami", "40223058", "tehran",
    "alborz", "ghadimi", "40223059", "bojnord",
    "garsha", "ghobadi", "40223060", "arak",
    "golnaz", "ghorbani", "40223061", "jahrom",
    "yalda", "ghalavand", "40223062", "ramshir",
    "arad", "ghomeishi", "40223063", "qazvin",
    "negar", "kazemi", "40223064", "rasht",
    "golrokh", "karami", "40223065", "shahsavar",
    "tina", "karimi", "40223066", "babol",
    "milad", "kavian", "40223067", "hamedan",
    "farzin", "kouhi", "40223068", "chalous",
    "kasra", "kavosh", "40223069", "amol",
    "helia", "kermani", "40223070", "kerman",
    "helena", "kordi", "40223071", "dehgolan",
    "hossein", "kamali", "40223072", "paveh",
    "hana", "kashipaz", "40223073", "qazvin",
    "nahal", "karaji", "40223074", "karaj",
    "farid", "kari", "40223075", "mashhad",
    "nina", "kasechi", "40223076", "tehran",
    "mahshid", "kordlou", "40223077", "arak",
    "sanaz", "kaveh", "40223078", "isfahan",
    "matin", "gorji", "40223079", "shiraz",
    "hoda", "goli", "40223080", "kerman",
    "sogol", "gohardoost", "40223081", "ghaemshahr",
    "mana", "gilani", "40223082", "bandaranzali",
    "sana", "golpayegani", "40223083", "golpayegan",
    "nastaran", "lotfi", "40223084", "karaj",
    "sam", "latifi", "40223085", "sousangerd",
    "benyamin", "lavasani", "40223086", "tehran",
    "nikoo", "langeroudi", "40223087", "langeroud",
    "mandana", "mahdavi", "40223088", "khoramshahr",
    "erfan", "mehdizadeh", "40223089", "bam",
    "bahareh", "manouchehry", "40223090", "malayer",
    "kimia", "misaghi", "40223091", "chabahar",
    "ashkan", "malakouti", "40223092", "masal",
    "sadaf", "mafakherian", "40223093", "isfahan", 
    "taher", "milani", "40223094", "arak",
    "marzieh", "mousavi", "40223095", "rasht",
    "melina", "moradi", "40223096", "tehran",
    "ghazal", "moradi", "40223097", "shiraz",
    "neda", "nouri", "40223098", "abadan",
    "ali", "nouri", "40223099", "ahvaz",
    "mohammad", "yari", "40223100", "mashhad"};

    FILE *pfile;
    pfile=fopen("projectlist.txt","w");
    if (pfile==NULL)
        printf("Error opening file\n");

        
    for (int i=0; i<100; i++)
        fprintf(pfile,"%-20s%-20s%-20s%-20s\n", student[i].FirstName, student[i].LastName, student[i].ID, student[i].City);


    fclose(pfile);


    for (int i = 0; i < 100; i++)
    {
        insert(&head, student[i]);
    }



    if(SDL_Init(SDL_INIT_EVERYTHING)!=0)
    {
        printf("Error initializing SDL: %s\n",SDL_GetError());
        return 0;
    }
    //create a window
    SDL_Window* window= SDL_CreateWindow("color box",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,WIDTH,HEIGHT,0);
    if(!window)
    {
        printf("Error creating window: %s\n",SDL_GetError());
        SDL_Quit();
        return 0;
    }

    SDL_Renderer *renderer= SDL_CreateRenderer(window, -1 ,SDL_RENDERER_ACCELERATED);
    //color and font
    TTF_Init();
    TTF_Font *font=TTF_OpenFont("arial.ttf",24);
    SDL_SetRenderDrawColor(renderer,25,42,217,255);
    SDL_RenderClear(renderer);

    SDL_Texture *texture;
    SDL_Rect rect={10,10,200,200}, text_rect ={10,10,200,200};
    SDL_SetRenderDrawColor(renderer, 171,210,250,100);
    SDL_RenderFillRect(renderer, &rect);
    get_text_and_rect(renderer, text_rect.x,text_rect.y,"1.read file", font, &texture, &text_rect);
    SDL_RenderCopy(renderer,texture,NULL,&text_rect);

    SDL_Rect rect2 = {220, 10, 200, 200}, text_rect2 = {220, 10, 200, 200};
    SDL_SetRenderDrawColor(renderer, 171,210,250,100);
    SDL_RenderFillRect(renderer, &rect2);
    get_text_and_rect(renderer, text_rect2.x, text_rect2.y, "2.search", font, &texture, &text_rect2);
    SDL_RenderCopy(renderer, texture, NULL, &text_rect2);

    SDL_Rect rect3 = {10, 220, 200, 200}, text_rect3 = {10, 220, 200, 200};
    SDL_SetRenderDrawColor(renderer, 171,210,250,100);
    SDL_RenderFillRect(renderer, &rect3);
    get_text_and_rect(renderer, text_rect3.x, text_rect3.y, "3.add student", font, &texture, &text_rect3);
    SDL_RenderCopy(renderer, texture, NULL, &text_rect3);

    SDL_Rect rect4 = {220, 220, 200, 200}, text_rect4 = {220, 220, 200, 400};
    SDL_SetRenderDrawColor(renderer, 171,210,250,100);
    SDL_RenderFillRect(renderer, &rect4);
    get_text_and_rect(renderer, text_rect4.x, text_rect4.y, "4.remove student", font, &texture, &text_rect4);
    SDL_RenderCopy(renderer, texture, NULL, &text_rect4);

    SDL_Rect rect5 = {10, 430, 200, 200}, text_rect5 = {10, 430, 200, 200};
    SDL_SetRenderDrawColor(renderer, 171,210,250,100);
    SDL_RenderFillRect(renderer, &rect5);
    get_text_and_rect(renderer, text_rect5.x, text_rect5.y, "5.random sort", font, &texture, &text_rect5);
    SDL_RenderCopy(renderer, texture, NULL, &text_rect5);

    SDL_Rect rect6 = {220, 430, 200, 200}, text_rect6 = {220, 430, 200, 200};
    SDL_SetRenderDrawColor(renderer, 171,210,250,100);
    SDL_RenderFillRect(renderer, &rect6);
    get_text_and_rect(renderer, text_rect6.x, text_rect6.y, "6.sort", font, &texture, &text_rect6);
    SDL_RenderCopy(renderer, texture, NULL, &text_rect6);

    SDL_Rect rect7 = {10, 640, 200, 200}, text_rect7 = {10, 640, 200, 200};
    SDL_SetRenderDrawColor(renderer,171,210,250,100);
    SDL_RenderFillRect(renderer, &rect7);
    get_text_and_rect(renderer, text_rect7.x, text_rect7.y, "7.write file", font, &texture, &text_rect7);
    SDL_RenderCopy(renderer, texture, NULL, &text_rect7);

    SDL_Rect rect8 = {220, 640, 200, 200}, text_rect8 = {220, 640, 200, 200};
    SDL_SetRenderDrawColor(renderer,171,210,250,100);
    SDL_RenderFillRect(renderer, &rect8);
    get_text_and_rect(renderer, text_rect8.x, text_rect8.y, "8.end program", font, &texture, &text_rect8);
    SDL_RenderCopy(renderer, texture, NULL, &text_rect8);

    SDL_RenderPresent(renderer);


    int running=1;
    SDL_Event event;
    while(running)
    {
        while (SDL_PollEvent(&event))
        {
            if (event.type==SDL_QUIT)
            {
                running=0;
                break;
            }
            if(event.type==SDL_MOUSEBUTTONDOWN && event.button.button== SDL_BUTTON(SDL_BUTTON_LEFT))
            {
                SDL_Point mousePosition;
                mousePosition.x= event. motion.x;
                mousePosition.y= event. motion.y;

                if(SDL_PointInRect(&mousePosition,&rect))
                    printLinkedList(head);
                if(SDL_PointInRect(&mousePosition,&rect2))
                    search(&head);
                if(SDL_PointInRect(&mousePosition,&rect3))
                    addstudent(&head);
                if(SDL_PointInRect(&mousePosition,&rect4))
                    removestudent(&head);
                if(SDL_PointInRect(&mousePosition,&rect5))
                    randomsort(student);
                if(SDL_PointInRect(&mousePosition,&rect6))
                    sort(student);
                if(SDL_PointInRect(&mousePosition,&rect7))
                    finalfile(&head);
                if(SDL_PointInRect(&mousePosition,&rect8))
                    break;
                
                
            }
        }
    }
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    

    //randomsort(student);
    //printLinkedList(head);
    //addstudent(&head);
    //search(&head);
    //removestudent(&head);
    //printLinkedList(head);
    //finalfile(&head);
    //sort(student);
    

    return 0;
}


void insert(struct Node** head, struct Student student)
{

    //dadan hafeze
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = student;
    newNode->next = NULL;

    if (*head == NULL) {
        newNode->prev = NULL;
        *head = newNode;
    } else {
        struct Node* lastNode = *head;
        while (lastNode->next != NULL)
        {
            lastNode = lastNode->next;
        }
        lastNode->next = newNode;
        newNode->prev = lastNode;
    }
}


void printLinkedList(struct Node* head)
{
    printf("%-5s%-20s%-20s%-20s%-20s\n","row" ,"First Name", "Last Name", "ID", "City");

    struct Node* CurrentNode = head;
    int i = 1;

    while (CurrentNode != NULL)
    {
        printf("%-5d%-20s%-20s%-20s%-20s\n",
               i, 
               CurrentNode->data.FirstName,
               CurrentNode->data.LastName,
               CurrentNode->data.ID,
               CurrentNode->data.City);

        CurrentNode = CurrentNode->next;
        i++;
    }
}


void search(struct Node** head)
{
    
    int targetRow;

    puts("enter the row you want");
    scanf("%d", &targetRow);

    int currentRow = 1;
    struct Node* current = *head;

    while (current != NULL) 
    {
        if (currentRow == targetRow)
        {

            printf("founded!!!!!!!!!! row %d:\n", currentRow);
            printf("hhhhhhh");

            printf("First Name: %s\n", current->data.FirstName);
            printf("Last Name: %s\n", current->data.LastName);
            printf("ID: %s\n", current->data.ID);
            printf("City: %s\n", current->data.City);
            return;
        }

        // bro badi
        current = current->next;
        currentRow++;
    }

    printf("No match found!!!!!!!!!\n");
}

void addstudent(struct Node** head) 
{
    
    int row;
    puts("enter row:");
    scanf("%d", &row);

    struct Student newStudent;

    puts("enter first name:");
    scanf("%s", newStudent.FirstName);
    
    puts("enter last name:");
    scanf("%s", newStudent.LastName);

    puts("enter city name:");
    scanf("%s", newStudent.City);

    puts("enter ID");
    scanf("%s", newStudent.ID);

    lowercase(newStudent);

    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = newStudent;
    newNode->next = NULL;

    if (row <= 1)
    {
        newNode->prev = NULL;
        newNode->next = *head;
        if (*head != NULL)
        {
            (*head)->prev = newNode;
        }
        *head = newNode;
    }
     else 
    {
        struct Node* current = *head;
        int i = 1;
       while (current != NULL && current->next != NULL) 
        {
            current = current->next;
            i++;
        }

        if (row < i) 
        {
            //specified row
            current = *head;
            i = 1;
            while (current != NULL && i < row - 1) 
            {
                current = current->next;
                i++;
            }

            newNode->next = current->next;
            newNode->prev = current;
            if (current->next != NULL) 
            {
                current->next->prev = newNode;
            }
            current->next = newNode;
        } 
        else 
        {
            //end of the list
            newNode->prev = current;
            current->next = newNode;
        }
    }
    printf("%-5s%-20s%-20s%-20s%-20s\n","row" ,"First Name", "Last Name", "ID", "City");

    struct Node* CurrentNode = *head;
    int i = 1;

    while (CurrentNode != NULL)
    {
        printf("%-5d%-20s%-20s%-20s%-20s\n",
               i, 
               CurrentNode->data.FirstName,
               CurrentNode->data.LastName,
               CurrentNode->data.ID,
               CurrentNode->data.City);

        CurrentNode = CurrentNode->next;
        i++;
    }

}


void lowercase(struct Student newstude)
{
    for(int i=0; i<strlen(newstude.FirstName); i++)
        newstude.FirstName[i]=tolower(newstude.FirstName[i]);
    for(int i=0; i<strlen(newstude.LastName); i++)
        newstude.LastName[i]=tolower(newstude.LastName[i]);
    for(int i=0; i<strlen(newstude.City); i++)
        newstude.City[i]=tolower(newstude.City[i]);
}


void removestudent(struct Node** head) 
{
    
    int targetRow;

    puts("enter the row you want to delelte:");
    scanf("%d", &targetRow);

    int currentRow = 1;

    struct Node* PrevCur = *head;
    struct Node* current;
    current = PrevCur->next;
    struct Node* AfterCur;
    AfterCur = current->next;

    while (current != NULL) 
    {

        if (currentRow == targetRow) 
        {
            PrevCur->next = AfterCur;
            AfterCur->prev = PrevCur;
        }

        current = current->next;
        currentRow++;
    }


    printf("%-5s%-20s%-20s%-20s%-20s\n","row" ,"First Name", "Last Name", "ID", "City");

    struct Node* CurrentNode = *head;
    int i = 1;

    while (CurrentNode != NULL)
    {
        printf("%-5d%-20s%-20s%-20s%-20s\n",
               i, 
               CurrentNode->data.FirstName,
               CurrentNode->data.LastName,
               CurrentNode->data.ID,
               CurrentNode->data.City);

        CurrentNode = CurrentNode->next;
        i++;
    }
}


void randomsort(struct Student Students[]) 
{

    srand(time(NULL));
    int size = 100;
    struct Student temp;
    for (int i = size-1; i>0; i--)
    {
        int j = rand()%(i+1);
        temp = Students[i];
        Students[i] = Students[j];
        Students[j] = temp;
    }
    printf("randoooom\n");
    
     for(int i = 0; i<size; i++)
        printf("%-5d%-20s%-20s%-20s%-20s\n", i+1 ,Students[i].FirstName, Students[i].LastName, Students[i].ID, Students[i].City);

    FILE *pfile2;
    pfile2=fopen("RandomList.txt","w");
    if (pfile2==NULL)
        printf("Error opening file\n");
    fprintf(pfile2,"row  First Name          Last Name           ID                  Place of birth\n");
    for(int i=0; i<100; i++)
        fprintf(pfile2,"%-5d%-20s%-20s%-20s%-20s\n", i+1 ,Students[i].FirstName, Students[i].LastName, Students[i].ID, Students[i].City);

    fclose(pfile2);
    
}


void sort(struct Student Students[])   
 {
    int column, a, type;
    printf("type your column (first name=1, last name=2, id=3, place of birth=4)\n");
    scanf("%d",&column);
    printf("ascending=1 or descending=2\n");
    scanf("%d",&a);
    printf("what kind of sort do you want(slectselion=1, insertion=2, bubble=3)\n");
    scanf("%d",&type);
    if( type==1)
        selectionsort(Students,a,column);
    
    else if(type==2)
        insertionsort(Students,a,column);
    
    else if( type==3)
        bubblesort(Students,a,column);


 }



 void selectionsort(struct Student Students[], int how, int which )
 {
    
    printf("selection sort\n");
    long tick1= clock();
    
    if(which == 1)
    {
        //soudi
        if( how == 1)
        {
            int i, j, min_idx;
            int size = 100;
            struct Student temp;  
            for (i = 0; i < size - 1; i++)
            {
                min_idx = i;
                for (j = i + 1; j < size; j++) 
                {
                    if (strcmp(Students[j].FirstName, Students[min_idx].FirstName) < 0)
                    {
                        min_idx = j;
                    }
                }
            temp = Students[min_idx];
            Students[min_idx] = Students[i];
            Students[i] = temp;
            }
        }
        //nozooli
        else
        {
            int i, j, min_idx;
            int size = 100;
            struct Student temp;
            for (i = 0; i < size - 1; i++) 
            {
                min_idx = i;
                for (j = i + 1; j < size; j++) 
                {
                    if (strcmp(Students[min_idx].FirstName, Students[j].FirstName) < 0) 
                    {
                        min_idx = j;
                    }
                }
            temp = Students[min_idx];
            Students[min_idx] = Students[i];
            Students[i] = temp;
            }
            
        }
        
    }
    else if (which == 2)
    {
        //soudi
        if( how == 1)
        {
            int i, j, min_idx;
            int size = 100;
            struct Student temp;
            for (i = 0; i < size - 1; i++) 
            {
                min_idx = i;
                for (j = i + 1; j < size; j++) 
                {
                    if (strcmp(Students[j].LastName, Students[min_idx].LastName) < 0) 
                    {
                        min_idx = j;
                    }
                }
            temp = Students[min_idx];
            Students[min_idx] = Students[i];
            Students[i] = temp;
            }
        }
        //nozooli
        else
        {
            int i, j, min_idx;
            int size = 100;
            struct Student temp;
            for (i = 0; i < size - 1; i++) 
            {
                min_idx = i;
                for (j = i + 1; j < size; j++) 
                {
                    if (strcmp(Students[min_idx].LastName, Students[j].LastName) < 0) 
                    {
                        min_idx = j;
                    }
                }
            temp = Students[min_idx];
            Students[min_idx] = Students[i];
            Students[i] = temp;
            }
            
        }
        
    }
    else if (which == 3)
    {
        //soudi
        if( how == 1)
        {
            int i, j, min_idx;
            int size = 100;
            struct Student temp;
            for (i = 0; i < size - 1; i++) 
            {
                min_idx = i;
                for (j = i + 1; j < size; j++) 
                {
                    if (strcmp(Students[j].ID, Students[min_idx].ID) < 0) 
                    {
                        min_idx = j;
                    }
                }
            temp = Students[min_idx];
            Students[min_idx] = Students[i];
            Students[i] = temp;
            }
        }
        //nozooli
        else
        {
            int i, j, min_idx;
            int size = 100;
            struct Student temp;
            for (i = 0; i < size - 1; i++) 
            {
                min_idx = i;
                for (j = i + 1; j < size; j++) 
                {
                    if (strcmp(Students[min_idx].ID, Students[j].ID) < 0) 
                    {
                        min_idx = j;
                    }
                }
            temp = Students[min_idx];
            Students[min_idx] = Students[i];
            Students[i] = temp;
            }
            
        }
        
    }
    else if (which == 4)
    {
        //soudi
        if( how == 1)
        {
            int i, j, min_idx;
            int size = 100;
            struct Student temp;
            for (i = 0; i < size - 1; i++) 
            {
                min_idx = i;
                for (j = i + 1; j < size; j++) 
                {
                    if (strcmp(Students[j].City, Students[min_idx].City) < 0) 
                    {
                        min_idx = j;
                    }
                }
            temp = Students[min_idx];
            Students[min_idx] = Students[i];
            Students[i] = temp;
            }
        }
        //nozooli
        else
        {
            int i, j, min_idx;
            int size = 100;
            struct Student temp;
            for (i = 0; i < size - 1; i++) 
            {
                min_idx = i;
                for (j = i + 1; j < size; j++) 
                {
                    if (strcmp(Students[min_idx].City, Students[j].City) < 0) 
                    {
                        min_idx = j;
                    }
                }
            temp = Students[min_idx];
            Students[min_idx] = Students[i];
            Students[i] = temp;
            }
            
        }
        
    }

    long tick2= clock();
    long ellapsed = tick2- tick1;
    double ellapsedTime= (double) ellapsed/CLOCKS_PER_SEC;

    for(int i = 0; i<100; i++)
            printf("%-5d%-20s%-20s%-20s%-20s\n", i+1 ,Students[i].FirstName, Students[i].LastName, Students[i].ID, Students[i].City);

    
    printf("time taken is %lf seconds\n", ellapsedTime);

    FILE *pfile3;
    pfile3=fopen("SelectionSortList.txt","w");
    if (pfile3==NULL)
        printf("Error opening file\n");
    fprintf(pfile3,"row  First Name          Last Name           ID                  Place of birth\n");
    for(int i=0; i<100; i++)
        fprintf(pfile3,"%-5d%-20s%-20s%-20s%-20s\n", i+1 ,Students[i].FirstName, Students[i].LastName, Students[i].ID, Students[i].City);
    fclose(pfile3);


   
}





void insertionsort(struct Student Students[], int how, int which )
{

    printf("insertion sort\n");
    int i, j, size = 100;
    struct Student key;
    long tick1 = clock();
    // name
    if(which == 1)
    {
        
        //soudi
        if(how == 1)
        {
            for (i = 1; i < size; i++)
            {
                
                key = Students[i];
                j = i - 1;
                while (j >= 0 && strcmp(key.FirstName, Students[j].FirstName)>0) 
                {
                    Students[j + 1] = Students[j];
                    j = j - 1;
                }
                Students[j +1] = key;

            }
            
        }
        else
        {
            for (i = 1; i < size; i++) 
            {
                
                key = Students[i];
                j = i - 1;
                while (j >= 0 && strcmp(key.FirstName, Students[j].FirstName)>0) 
                {
                    Students[j + 1] = Students[j];
                    j = j - 1;
                }
                Students[j +1] = key;

            }

        }
        
    }
        
    if(which == 2)
        {
        
        //soudi
        if(how == 1)
        {
            for (i = 1; i < size; i++) 
            {
                
                key = Students[i];
                j = i - 1;
                while (j >= 0 && strcmp(key.LastName, Students[j].LastName)>0) 
                {
                    Students[j + 1] = Students[j];
                    j = j - 1;
                }
                Students[j +1] = key;

            }
            
        }
        else
        {
            for (i = 1; i < size; i++) 
            {
                
                key = Students[i];
                j = i - 1;
                while (j >= 0 && strcmp(key.LastName, Students[j].LastName)>0) 
                {
                    Students[j + 1] = Students[j];
                    j = j - 1;
                }
                Students[j +1] = key;

            }
        }
        }
        
    if(which == 3)
        {
        
        //soudi
        if(how == 1)
        {
            for (i = 1; i < size; i++) 
            {
                
                key = Students[i];
                j = i - 1;
                while (j >= 0 && strcmp(key.ID, Students[j].ID)>0) 
                {
                    Students[j + 1] = Students[j];
                    j = j - 1;
                }
                Students[j +1] = key;

            }
            
        }
        else
        {
            for (i = 1; i < size; i++) 
            {
                
                key = Students[i];
                j = i - 1;
                while (j >= 0 && strcmp(key.ID, Students[j].ID)>0) 
                {
                    Students[j + 1] = Students[j];
                    j = j - 1;
                }
                Students[j +1] = key;

            }
        }
        

    }

    if(which == 4)
    {
        
        //soudi
        if(how == 1)
        {
            for (i = 1; i < size; i++) 
            {
                
                key = Students[i];
                j = i - 1;
                while (j >= 0 && strcmp(key.City, Students[j].City)>0) 
                {
                    Students[j + 1] = Students[j];
                    j = j - 1;
                }
                Students[j +1] = key;

            }
            
        }
        else
        {
             for (i = 1; i < size; i++) 
             {
                
                key = Students[i];
                j = i - 1;
                while (j >= 0 && strcmp(key.City, Students[j].City)>0) 
                {
                    Students[j + 1] = Students[j];
                    j = j - 1;
                }
                Students[j +1] = key;

            }
        }
        
    }

    long tick2= clock();
    long ellapsed = tick2- tick1;
    double ellapsedTime= (double) ellapsed/CLOCKS_PER_SEC;

    for(int i = 0; i<size; i++)
        printf("%-5d%-20s%-20s%-20s%-20s\n", i+1 ,Students[i].FirstName, Students[i].LastName, Students[i].ID, Students[i].City);


    
    printf("time taken is %lf seconds\n", ellapsedTime);



    FILE *pfile4;
    pfile4=fopen("insertionSortList.txt","w");
    if (pfile4==NULL)
        printf("Error opening file\n");
    fprintf(pfile4,"row  First Name          Last Name           ID                  Place of birth\n");
    for(int i=0; i<100; i++)
        fprintf(pfile4,"%-5d%-20s%-20s%-20s%-20s\n", i+1 ,Students[i].FirstName, Students[i].LastName, Students[i].ID, Students[i].City);
        fclose(pfile4);


    }




void bubblesort(struct Student Students[], int how, int which )
{
    
    
    struct Student temp;
    int size = 100;
    printf("buble sort\n");

    long tick1= clock();

    // soudi
    if (which == 1)
    {

        if(how == 1)
        {

            for (int i = 0; i < size; i++)
            {
                for(int j = 0; j <size; j++)
                {

                    if(strcmp(Students[j].FirstName,Students[i].FirstName)>0)
                    {
                        temp = Students[i];
                        Students[i] = Students[j];
                        Students[j] = temp;

                    }
                }
            }
     
        }
    //nozooli
        else
        {
            for (int i = 0; i < size; i++)
            {
                for(int j = 0; j <size; j++)
                {

                    if(strcmp(Students[j].FirstName,Students[i].FirstName)<0)
                    {
                        temp = Students[i];
                        Students[i] = Students[j];
                        Students[j] = temp;

                    }
                }
            }
        }
    }
    else if (which == 2)
    {
        if(how == 1)
        {
            for (int i = 0; i < size; i++)
            {
                for(int j = 0; j <size; j++)
                {

                    if(strcmp(Students[i].LastName,Students[j].LastName)>0)
                    {
                        temp = Students[i];
                        Students[i] = Students[j];
                        Students[j] = temp;

                    }
                }
            }
    
        }
    //nozooli
        else
        {
            for (int i = 0; i < size; i++)
            {
                for(int j = 0; j <size; j++)
                {

                    if(strcmp(Students[j].LastName,Students[i].LastName)>0)
                    {
                        temp = Students[i];
                        Students[i] = Students[j];
                        Students[j] = temp;

                    }
                }
            }
        }
    }
    
    else if (which == 3)
    {
        if(how == 1)
        {
            for (int i = 0; i < size; i++)
            {
                for(int j = 0; j <size; j++)
                {

                    if(strcmp(Students[i].ID,Students[j].ID)>0)
                    {
                        temp = Students[i];
                        Students[i] = Students[j];
                        Students[j] = temp;

                    }
                }
             }
    
        }
    //nozooli
        else
        {
            for (int i = 0; i < size; i++)
            {
                for(int j = 0; j < size; j++)
                {

                    if(strcmp(Students[j].ID,Students[i].ID)>0)
                    {
                        temp = Students[i];
                        Students[i] = Students[j];
                        Students[j] = temp;

                    }
                }
            }
        }
    }
    else if (which == 4)
    {
        if(how == 1)
        {
            for (int i = 0; i < size; i++)
            {
                for(int j = 0; j < size; j++)
                {

                    if(strcmp(Students[i].City,Students[j].City)>0)
                    {
                    temp = Students[i];
                    Students[i] = Students[j];
                    Students[j] = temp;

                    }
                }
            }
   
        } 
        //nozooli
        else
        {
            for (int i = 0; i < size; i++)
            {
                for(int j = 0; j <size; j++)
                {

                    if(strcmp(Students[j].City,Students[i].City)>0)
                    {
                        temp = Students[i];
                        Students[i] = Students[j];
                        Students[j] = temp;

                    }
                }
            }
        }
    }
    
    long tick2= clock();
    long ellapsed = tick2- tick1;
    double ellapsedTime= (double) ellapsed/CLOCKS_PER_SEC;


    // print sorted array
    for(int i = 0; i<size; i++)
        printf("%-5d%-20s%-20s%-20s%-20s\n", i+1,Students[i].FirstName, Students[i].LastName, Students[i].ID, Students[i].City);

    
    printf("time taken is %lf seconds\n", ellapsedTime);


    FILE *pfile5;
    pfile5=fopen("bubbleSortList.txt","w");
    if (pfile5==NULL)
        printf("Error opening file\n");
    fprintf(pfile5,"row  First Name          Last Name           ID                  Place of birth\n");
    for(int i=0; i<100; i++)
        fprintf(pfile5,"%-5d%-20s%-20s%-20s%-20s\n", i+1 ,Students[i].FirstName, Students[i].LastName, Students[i].ID, Students[i].City);
        fclose(pfile5);


    
}


void finalfile(struct Node** head)
{

    FILE *pfile;
    pfile=fopen("projectlist.txt","a");
    if (pfile==NULL)
        printf("Error opening file\n");
    fputs("___________________________________________________________________\n",pfile);
    fprintf(pfile,"row  First Name          Last Name           ID                  Place of birth\n");
    struct Node* current_node = *head;
    int i = 1;

    while (current_node != NULL)
    {
        fprintf(pfile,"%-5d%-20s%-20s%-20s%-20s\n",
               i, 
               current_node->data.FirstName,
               current_node->data.LastName,
               current_node->data.ID,
               current_node->data.City);

        current_node = current_node->next;
        i++;
    }
    fclose(pfile);

    FILE *pfile6;
    pfile6=fopen("binarylist.bin","wb");
    if (pfile6==NULL)
        printf("Error opening file\n");
    struct Node* current_node1 = *head;
    i = 1;

    while (current_node != NULL)
    {
        fwrite(&(current_node1->data),sizeof(current_node1->data),1,pfile6);
        current_node = current_node->next;
        i++;
    }
        fclose(pfile6);
}


    void get_text_and_rect(SDL_Renderer *renderer , int x, int y, char *text,TTF_Font *font, SDL_Texture **texture, SDL_Rect *rect)
    {
        int text_width;
        int text_height;
        SDL_Surface *surface;
        SDL_Color textcolor = {0,0,0,0};

        surface =TTF_RenderText_Solid(font, text, textcolor);
        *texture =SDL_CreateTextureFromSurface(renderer,surface);
        text_width=surface->w;
        text_height=surface->h;
        SDL_FreeSurface(surface);
        rect->x=x;
        rect->y=y;
        rect->w=text_width;
        rect->h=text_height;
    }
    
